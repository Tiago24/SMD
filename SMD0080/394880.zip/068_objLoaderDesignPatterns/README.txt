O que há de novo?
 - Renderer agora cuida de quase todos os aspectos do OpenGL;
 - Suporte a múltiplas luzes via Renderer; 
 - controle de câmera usando o sistema local de coordenadas;
 - Material agora possui uma textura associada!
 