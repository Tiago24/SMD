g++ --std=c++11 -Iinclude *.cpp src/*.cpp src/loader/*.cpp -o bin/demo -lIL -lILU -lILUT -lGL -lGLU -lglut 

./bin/demo

