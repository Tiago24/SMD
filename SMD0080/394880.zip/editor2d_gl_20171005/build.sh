g++ --std=c++11 -Iinclude src/*.cpp -o bin/demo -lGL -lglut

./bin/demo

